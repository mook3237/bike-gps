# 자전거 GPS 트래커 — GitHub Pages 버전

## GitHub Secret으로 카카오 지도 키 사용하기

이 프로젝트는 실제 카카오 JavaScript 키를 저장소에 직접 넣지 않습니다.
GitHub Actions가 배포할 때 `KAKAO_MAP_API_KEY` Secret을 `config.js`에 주입합니다.

### 1. GitHub Secret 만들기

GitHub 저장소에서:

`Settings → Secrets and variables → Actions → New repository secret`

이름을 정확히:

`KAKAO_MAP_API_KEY`

로 만들고, 카카오 Developers에서 발급받은 **JavaScript 키**를 값으로 넣으세요.

### 2. GitHub Pages 설정

저장소의 `Settings → Pages`에서 **Source를 GitHub Actions**로 선택하세요.

이후 `main` 브랜치에 push하면 `.github/workflows/pages.yml`이 자동으로 배포합니다.

### 3. 카카오 Developers 도메인 등록

카카오 Developers에서 Web 플랫폼에 실제 GitHub Pages 주소를 등록해야 합니다.
예:

`https://YOUR_ID.github.io`

프로젝트 페이지라면:

`https://YOUR_ID.github.io/REPOSITORY_NAME/`

### 4. 중요한 보안 사실

카카오 Maps JavaScript 키는 브라우저에서 사용해야 하므로 배포된 웹페이지에서는 결국 노출됩니다.
GitHub Secret은 **소스 저장소에 키를 커밋하지 않기 위한 보호 수단**입니다.
카카오 Developers에서 반드시 허용 도메인을 제한하세요.

## 기능

- 카카오맵
- 현재 위치 GPS
- 속도 / 평균속도 / 최고속도 / 거리
- 목적지 검색 및 Enter 입력
- 지도 클릭 목적지 지정
- 편도 / 왕복
- OpenStreetMap + Valhalla 자전거 라우팅
- 자전거 경로 우선 라우팅
- 실제 주행 경로 표시
- 주행 기록 JSON 저장
